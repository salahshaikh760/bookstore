<?php
$servername = "localhost";
$username = "root";
$password = ""; // Default password in XAMPP is empty
$database = "bookstore_db"; // Make sure this database exists in phpMyAdmin

// Create a MySQLi connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
