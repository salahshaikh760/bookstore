<?php
session_start();
include 'db.php';

// Logic: Add item to session cart
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['book_id'])) {
    $book_id = intval($_POST['book_id']);
    if (!isset($_SESSION['cart'])) { $_SESSION['cart'] = []; }
    if (!in_array($book_id, $_SESSION['cart'])) { $_SESSION['cart'][] = $book_id; }
    
    // Redirect to prevent form resubmission
    header("Location: cart.php");
    exit();
}

// Logic: Fetch Cart Items
$cart_books = [];
$total_price = 0;
if (!empty($_SESSION['cart'])) {
    $book_ids = implode(',', array_map('intval', $_SESSION['cart']));
    $result = $conn->query("SELECT * FROM books WHERE id IN ($book_ids)");
    while ($book = $result->fetch_assoc()) {
        $cart_books[] = $book;
        $total_price += $book['price'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Shopping Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-light">

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4 text-center"><i class="fas fa-shopping-bag text-primary"></i> Your Shopping Cart</h2>

    <?php if (!empty($cart_books)): ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4">Product</th>
                                    <th>Price</th>
                                    <th class="text-end pe-4">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_books as $book): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-light rounded p-2 me-3 text-center" style="width: 50px; height: 50px;">
                                                <i class="fas fa-book text-muted"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($book['title']); ?></h6>
                                                <small class="text-muted"><?php echo htmlspecialchars($book['author']); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="fw-bold">₹<?php echo number_format($book['price'], 2); ?></td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-outline-danger btn-sm" disabled title="Remove feature coming soon">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Order Summary</h5>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal</span>
                            <span>₹<?php echo number_format($total_price, 2); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span>Shipping</span>
                            <span class="text-success">Free</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total</span>
                            <span class="fw-bold fs-5 text-primary">₹<?php echo number_format($total_price, 2); ?></span>
                        </div>
                        <form method="POST" action="checkout.php">
                            <button type="submit" class="btn btn-success w-100 btn-lg shadow-sm">
                                Proceed to Checkout <i class="fas fa-arrow-right ms-2"></i>
                            </button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="index.php" class="text-decoration-none">Continue Shopping</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="text-center py-5">
            <div class="mb-3">
                <i class="fas fa-shopping-basket fa-4x text-muted"></i>
            </div>
            <h4 class="text-muted">Your cart is empty</h4>
            <a href="index.php" class="btn btn-primary mt-3">Start Shopping</a>
        </div>
    <?php endif; ?>
</div>

</body>
</html>