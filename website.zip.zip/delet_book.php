<?php
session_start();
include 'db.php'; // Connect to the database

// Ensure the user is logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Check if the book ID is set
if (isset($_GET["id"])) {
    $book_id = $_GET["id"];

    // Prepare DELETE statement
    $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
    $stmt->bind_param("i", $book_id); // "i" means integer

    if ($stmt->execute()) {
        echo "Book deleted successfully!";
    } else {
        echo "Error deleting book: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    // Redirect back to dashboard
    header("Location: dashboard.php");
    exit();
} else {
    echo "Invalid request.";
}
?>
