<?php
$new_password = "admin123";
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

echo "New Hashed Password: " . $hashed_password;
?>
