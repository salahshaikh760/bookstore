<?php
include 'db.php';

$new_password = "admin123"; // New password you want to set
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

$email = "your_email@example.com"; // Replace with your email

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmt->bind_param("ss", $hashed_password, $email);

if ($stmt->execute()) {
    echo "Password reset successful! Use 'admin123' to log in.";
} else {
    echo "Error updating password: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
