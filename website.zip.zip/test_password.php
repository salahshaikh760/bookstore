<?php
$entered_password = "123456";
$hashed_password = '$2y$10$Y1zOaV9xuMGn4CgxJhi4AeKH6UQmPZhEdMm3qysMo/mB84PKToCH6'; // Correctly enclosed in single quotes

if (password_verify($entered_password, $hashed_password)) {
    echo "Password is correct!";
} else {
    echo "Password is incorrect!";
}
?>
